$(document).ready(function () {
    $('#hiddenTable').DataTable({
        dom: 'Bfrtip',
        buttons: ['csv', 'excel', 'pdf', 'print']
    });
});

$("#buttons-csv").on("click", function () {
    $('.buttons-csv').click();
});

$("#buttons-excel").on("click", function () {
    $('.buttons-excel').click();
});

$("#buttons-pdf").on("click", function () {
    $('.buttons-pdf').click();
});

$("#buttons-print").on("click", function () {
    $('.buttons-print').click();
});

// buttons-csv
// buttons-excel
// buttons-pdf
// buttons-print